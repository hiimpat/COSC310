package net.jhavar.exceptions;

public class NotSameHostException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public NotSameHostException(String exception) {
		super(exception);
	}
}
