package core.language;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import edu.smu.tspell.wordnet.*;

public class SynRec {

	public static void main(String[] args) {
		BufferedReader read;
		try {
			read = new BufferedReader(new FileReader("responsesInitial.txt"));
			String line = read.readLine();
			while (line != null) {
				ArrayList<String> words = getWords(line);
				String response;
				try {
				response = getResponse(line);
				} catch(Exception e) {
					response = "";
				}
				String newline = genLine(getSyns(words), response);
				if(newline != null)
					Files.write(Paths.get("responsesSynonyms.txt"), newline.getBytes(), StandardOpenOption.APPEND);
				
				line = read.readLine();
			}
			read.close();
		} catch (IOException e) {
			System.out.println("Something went wrong");
		}

	}

	public static ArrayList<String> getWords(String line) {
		String words = (line.split("\\|"))[0];
		String[] temp = words.split(";");
		ArrayList<String> word = new ArrayList<String>(Arrays.asList(temp));
		for (int i = 0; i < word.size(); i++) {
			if (word.get(i).contains(" ")) {
				word.remove(i);
				i--;
			}
		}
		return word;
	}

	public static String getResponse(String line) {
		return (line.split("\\|"))[1];
	}

	public static String genLine(ArrayList<String> words, String res) {
		String line = "\n";
		if(words.size()==0)
			return null;
		for (int i = 0; i < words.size(); i++) {
			line += words.get(i);
			if (i == words.size() - 1)
				break;
			line += ";";
		}
		line += "|" + res;
		return line;
	}

	public static ArrayList<String> getSyns(String word) {
		Set<String> temp = new HashSet<String>();
		ArrayList<String> syns = null;
		System.setProperty("wordnet.database.dir", "WordNet-3.0\\dict");
		WordNetDatabase database = WordNetDatabase.getFileInstance();
		Synset[] synsets = database.getSynsets(word);

		if (synsets.length > 0) {
			for (int i = 0; i < synsets.length; i++) {
				String[] wordForms = synsets[i].getWordForms();
				for (int j = 0; j < wordForms.length; j++) {
					temp.add(wordForms[j]);
				}
			}
			syns = new ArrayList<String>(temp);
		}
		return syns;
	}

	public static ArrayList<String> getSyns(ArrayList<String> words) {
		ArrayList<String> temp = new ArrayList<String>();
		Set<String> temp2 = new HashSet<String>();

		for (int i = 0; i < words.size(); i++) {
			temp = getSyns(words.get(i));
			if (temp != null) {
				for (int j = 0; j < temp.size(); j++) {
					temp2.add(temp.get(j));
				}
			}
		}

		ArrayList<String> syns = new ArrayList<String>(temp2);
		return syns;
	}
}