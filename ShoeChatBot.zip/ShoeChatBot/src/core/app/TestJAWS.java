package core.app;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import edu.smu.tspell.wordnet.*;

public class TestJAWS {

//	public static void main(String[] args) {
//		ArrayList<String> s = getSyns("bad");
//		for (int i = 0; i < s.size(); i++) {
//			System.out.println(s.get(i));
//		}
//	}

	public ArrayList<String> getSyns(String word) {
		Set<String> temp = new HashSet<String>();
		ArrayList<String> syns = null;
		System.setProperty("wordnet.database.dir", "WordNet-3.0\\dict");
		WordNetDatabase database = WordNetDatabase.getFileInstance();
		Synset[] synsets = database.getSynsets(word);

		if (synsets.length > 0) {
			for (int i = 0; i < synsets.length; i++) {
				String[] wordForms = synsets[i].getWordForms();
				for (int j = 0; j < wordForms.length; j++) {
					temp.add(wordForms[j]);
				}
			}
			syns = new ArrayList<String>(temp);
			for (int i = 0; i < syns.size(); i++) {
				System.out.println(syns.get(i));
			}
		}
		return syns;
	}
}