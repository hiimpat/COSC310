package core.app;

/**
 * 
 * Holds the information that the user has received so far this chat session
 * Helps make decisions in chat / store responses.
 * 
 * @author Raghav
 *
 */
public class ChatSession {
	
	private static Product[] productsPresented;
	private static Product selectedProduct;
	public static int chatStage = 0;

	public static void setProductsPresented(Product[] products) {
		productsPresented = products;
		chatStage = 1;
	}

	private static String setSelectedProduct(int num) {
		if (num > productsPresented.length) {
			return "That's not an invalid choice! Try again.";
		}
		selectedProduct = productsPresented[num - 1];
		chatStage = 2;
		return "Alright, selected " + selectedProduct.getDisplayName() + " for $" + selectedProduct.getPrice() + ". Would you like to checkout?";
	}

	public static String setSelectedProduct(String name) {
		//Check if they entered a number
		try {
			return setSelectedProduct(Integer.parseInt(name));
		} catch (NumberFormatException e) {
			
			for (int i = 0; i < productsPresented.length; i++) {
				if(isProduct(name.toLowerCase(), productsPresented[i].getDisplayName().toLowerCase()) > 0) {
					selectedProduct = productsPresented[i];
					break;
				}
			}
			chatStage = 2;
			return "Alright, selected " + selectedProduct.getDisplayName() + " for $" + selectedProduct.getPrice() + ". Would you like to checkout?";
		}
	}
	
	public static String checkout() {
		chatStage = 3;
		return "Successfully checked out your product: " + selectedProduct.getDisplayName() + ".\nWould you like to purchase another one?";
	}	
	
	private static int isProduct(String input, String comparingTo) {
		int a = input.indexOf(comparingTo);
		int b= comparingTo.indexOf(input);
		return a >= b ? a : b;
	}
	
	public static Product getSelectedProduct() {
		return ChatSession.selectedProduct;
	}
}
